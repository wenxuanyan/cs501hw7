package com.example.sse.customlistview_sse;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.MediaController;
import android.widget.VideoView;

// a separate intent for the videoview to be able to go back by pressing the back button to go to the list layout

public class VideoActivity extends AppCompatActivity {

    VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.video);
        String uriPath = "android.resource://"+getPackageName()+"/"+R.raw.khan;
        Uri uri = Uri.parse(uriPath);
        // initialize videoView to be able to play Khan clip
        videoView = (VideoView) findViewById(R.id.videoView);
        videoView.setMediaController(new MediaController(this));
        videoView.setVideoURI(uri);
        videoView.start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // switch case for going back to home (MainActivity)
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
}

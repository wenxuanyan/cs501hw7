package com.example.ws8_p2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private SharedPreferences sp;
    private Button swap;
    private EditText et1;
    private ImageView imgv1;
    private static int[] imageList = {R.drawable.whitedog,R.drawable.yellowdog,R.drawable.blackdog};
    private int imageListIndex = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences("storage1", Context.MODE_PRIVATE);
        swap = findViewById(R.id.button);
        et1 = findViewById(R.id.editTextTextPersonName);
        imgv1 = findViewById(R.id.imageView);
        reload(); //reload information in sharedPreference
        imgv1.setBackgroundResource(imageList[imageListIndex]);

        swap.setOnClickListener(view -> { loadImgs();});
    }
    private void loadImgs(){
        //increment the image index and load the image
        imageListIndex = (imageListIndex+1)%3;
        imgv1.setBackgroundResource(imageList[imageListIndex]);
    }

    protected void onDestroy() {
        //save information in sharedPreference
        SharedPreferences.Editor editor = sp.edit();
        String editTextInfo = et1.getText().toString();
        editor.putInt("index", imageListIndex);
        editor.putString("etInfo", editTextInfo);
        editor.apply();
        super.onDestroy();
    }
    private void reload(){
        //reload information in sharedPreference
        if(sp.contains("index")){
            imageListIndex = sp.getInt("index",0);
            imgv1.setBackgroundResource(imageList[imageListIndex]);
        }
        if(sp.contains("etInfo")){
            String editTextInfo = sp.getString("etInfo","");
            et1.setText(editTextInfo);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }
}